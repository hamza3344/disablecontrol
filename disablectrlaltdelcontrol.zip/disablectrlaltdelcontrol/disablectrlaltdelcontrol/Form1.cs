﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace disablectrlaltdelcontrol
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode== Keys.Up || e.KeyCode== Keys.Down || e.KeyCode==Keys.Right || e.KeyCode==Keys.Left
                || e.Modifiers.ToString()=="Shift") { 
            }
            else
            {
                if(Convert.ToBoolean(e.Modifiers))
                {
                    e.SuppressKeyPress = true;
                }
                else
                {
                    e.Handled = true;
                }
            }
        }
    }
}
